﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Npgsql;

class Program
{
    static void Main(string[] args)
    {
        string connectionString = "Host=localhost;Username=postgres;Password=venyra;Database=PBO";
        NpgsqlConnection connection = new NpgsqlConnection(connectionString);
        connection.Open();
        // sekumpulan perintah SQL
        connection.Close();
    }
}



